"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function ItemList() {
  const [inputValue, setInputValue] = useState("")
  const [items, setItems] = useState<string[]>([])

  const handleAddItem = () => {
    if (inputValue.trim() !== "") {
      setItems([...items, inputValue])
      setInputValue("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleAddItem()
    }
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-50">
      <div className="w-full max-w-md space-y-6">
        <h1 className="text-2xl font-bold text-center">Item List</h1>
        
        <div className="flex space-x-2">
          <Input
            type="text"
            placeholder="Enter an item"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1"
          />
          <Button onClick={handleAddItem}>Add Item</Button>
        </div>
        
        <div className="border rounded-md bg-white p-4 min-h-[200px]">
          {items.length === 0 ? (
            <p className="text-gray-400 text-center">No items added yet</p>
          ) : (
            <ul className="space-y-2">
              {items.map((item, index) => (
                <li key={index} className="py-2 border-b border-gray-100 last:border-0">
                  {item}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  )
}

